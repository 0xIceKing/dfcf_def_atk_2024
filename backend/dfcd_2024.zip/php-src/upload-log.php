<?php
error_reporting(-1);
ini_set('display_errors', 1);

date_default_timezone_set('Asia/Ho_Chi_Minh');
$date = date('Y-m-d H:i');
$log_dir = __DIR__.'/../logs/'.$date;
@mkdir($log_dir);
$log_file = $_FILES['log'];
if (move_uploaded_file($log_file['tmp_name'], $log_dir.'/'.$log_file['name'])) {
  echo 'Upload OK: '.$date.'/'.$log_file['name'];
}else{
  echo 'Upload Failed';
}
